package com.voxelbusters.nativeplugins.features.webview;

import android.app.Activity;

public class NativeWebViewActivity extends Activity
{

}
